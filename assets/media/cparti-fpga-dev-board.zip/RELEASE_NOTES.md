# CPArti FPGA dev board — rev_01

**Released:** 2026-05-28 15:55:38 -04:00

**KiCad version:** 10.0.3 (flatpak)

**Host OS:** Linux Mint (kernel 6.17.0-29-generic)

**Git commit:** `67110ed` ⚠ working tree dirty — release contains uncommitted or untracked files not represented by this hash

## Description

Dev board, FPGA; XIlinx Artix-7, available on Github

## Changes from previous version

_(none provided)_

